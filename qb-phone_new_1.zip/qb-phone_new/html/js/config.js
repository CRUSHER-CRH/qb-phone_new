Config = []

Config.HeaderDisabledApps = [
    "bank", 
    "whatsapp", 
    "meos", 
    "garage",
    "crypto",
    "racing",
    "houses",
    "lawyers",
    "trucker",
]

Config.DefaultCryptoPage = "general";